#pragma once
extern "C" { int gettimeofday(struct timeval *tv, struct timezone *tz); }
