aclocal && autoheader && autoconf && automake
